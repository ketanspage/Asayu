import React from 'react'

function Brand() {
  return (
    <div>
      Hello from Brand
    </div>
  )
}

export default Brand
