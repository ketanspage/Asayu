import React from 'react'

function about() {
  return (
    <div>
      hello from about
    </div>
  )
}

export default about
