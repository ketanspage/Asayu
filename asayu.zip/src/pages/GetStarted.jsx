import React from 'react'

function GetStarted() {
  return (
    <div>
      hello from get started
    </div>
  )
}

export default GetStarted
