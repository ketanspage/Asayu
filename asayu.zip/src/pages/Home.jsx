import React from 'react'

function home() {
  return (
    <div>
      hello from home
    </div>
  )
}

export default home
